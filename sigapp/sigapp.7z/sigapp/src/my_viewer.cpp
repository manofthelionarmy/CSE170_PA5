
# include "my_viewer.h"

# include <sigogl/ui_button.h>
# include <sigogl/ui_radio_button.h>
# include <sig/sn_primitive.h>
# include <sig/sn_transform.h>
# include <sig/sn_manipulator.h>

# include <sigogl/ws_run.h>
bool _smooth = false;
MyViewer::MyViewer ( int x, int y, int w, int h, const char* l ) : WsViewer(x,y,w,h,l)
{
	_nbut=0;
	_animating=false;
	build_ui ();
	build_scene ();
}

void MyViewer::build_ui ()
{
	UiPanel *p, *sp;
	UiManager* uim = WsWindow::uim();
	p = uim->add_panel ( "", UiPanel::HorizLeft );
	p->add ( new UiButton ( "View", sp=new UiPanel() ) );
	{	UiPanel* p=sp;
		p->add ( _nbut=new UiCheckButton ( "Normals", EvNormals ) ); 
	}
	p->add ( new UiButton ( "Animate", EvAnimate ) );
	p->add ( new UiButton ( "Exit", EvExit ) ); p->top()->separate();
}

void MyViewer::add_model ( SnShape* s, GsVec p )
{
	SnManipulator* manip = new SnManipulator;
	GsMat m;
	m.translation ( p );
	manip->initial_mat ( m );

	SnGroup* g = new SnGroup;
	SnLines* l = new SnLines;
	l->color(GsColor::orange);
	g->add(s);
	g->add(l);
	manip->child(g);

	rootg()->add(manip);
}
GsVec torusFunction(int phi, int theta, float r, float R) {
	float x = 0.0f; 
	float y = 0.0f; 
	float z = 0.0f; 
	float alpha = GS_TORAD(float(phi));
	float beta = GS_TORAD(float(theta));

	x = float(R + r * cosf(alpha))*cosf(beta);
	y = float(R + r * cosf(alpha)) * sinf(beta);
	z = float(r * sinf(alpha));

	return GsVec(x, y, z);
}
void MyViewer::build_scene ()
{
	GsModel *torus = new GsModel();


	int prevPhi = 0;
	int prevTheta = 0;

	int nextPhi = 0;
	int nextTheta = 0;

	float x = 0.0f;
	float y = 0.0f;
	float z = 0.0f;

	float r = 0.1f;
	float R = 0.5f;
	int numTriangles = 10;

	int a = 0; 
	int b = 1; 
	int c = 2; 

	int d = 3; 
	int e = 4; 
	int f = 5; 

	for (nextPhi = 10; nextPhi <= 360; nextPhi += 10) {
		for (nextTheta = 10; nextTheta <= 360; nextTheta += 10) {

			GsVec A00 = torusFunction(prevPhi, prevTheta, r, R);
			GsVec A10 = torusFunction(nextPhi, prevTheta, r, R);
			GsVec A01 = torusFunction(prevPhi, nextTheta, r, R);
			GsVec A11 = torusFunction(nextPhi, nextTheta, r, R);

			torus->V.push() = A00;
			torus->V.push() = A10;
			torus->V.push() = A01;

			torus->V.push() = A10;
			torus->V.push() = A11;
			torus->V.push() = A01;

			GsModel::Face f1 = GsModel::Face(a, b, c);
			GsModel::Face f2 = GsModel::Face(d, e, f);
			
			
			torus->F.push() = f1;
			torus->F.push() = f2;



			if (_smooth) {
				double w = (cos(GS_TORAD(prevPhi))*cos(GS_TORAD(prevTheta)));
				double h = (cos(a))*sin(b);
				double z = sin(a);

				double w1 = (cos(GS_TORAD(nextPhi)))*cos(GS_TORAD(prevTheta)));
				double h1 = (GS_TORAD(nextPhi))*sin(GS_TORAD(prevTheta));
				double z1 = sin(GS_TORAD(nextPhi));

				double w2 = (cos(a))*cos(GS_TORAD(nextTheta));
				double h2 = (cos(a))*sin(GS_TORAD(nextTheta));
				double z2 = sin(a);

				double w3 = (GS_TORAD(nextPhi))*cos(GS_TORAD(nextTheta));
				double h3 = (cos(GS_TORAD(nextPhi))*sin(GS_TORAD(nextTheta));
				double z3 = sin(cos(GS_TORAD(nextPhi)));
				torus->N.push() = GsVec(w, h, z);
				torus->N.push() = GsVec(w2, h2, z2);
				torus->N.push() = GsVec(w1, h1, z1);
				torus->N.push() = GsVec(w3, h3, z3);
				torus->N.push() = GsVec(w1, h1, z1);
				torus->N.push() = GsVec(w2, h2, z2);
			}
			

			if (_smooth == false)
			{
				GsVec u = (torus->V[f1.b] - torus->V[f1.a]);
				GsVec v = (torus->V[f1.c] - torus->V[f1.a]);

				float Nx = u.y* v.z - u.z*v.y;
				float Ny = u.z*v.x - u.x*v.z;

				float Nz = u.x*v.y - u.y*v.x;
				torus->N.push() = GsVec(Nx, Ny, Nz);
				torus->Fn.push(GsModel::Face(0, 0, 0));

				u = (torus->V[f2.b] - torus->V[f2.a]);
				v = (torus->V[f2.c] - torus->V[f2.a]);

				Nx = u.y* v.z - u.z*v.y;
				Ny = u.z*v.x - u.x*v.z;

				Nz = u.x*v.y - u.y*v.x;

				torus->N.push() = GsVec(Nx, Ny, Nz);
				torus->Fn.push(GsModel::Face(1, 1, 1));

				torus->set_mode(GsModel::Flat, GsModel::NoMtl);
			}
			


			prevTheta = nextTheta;
			a += 6;
			b += 6;
			c += 6; 
			d += 6;
			e += 6; 
			f += 6;
		}

		
		prevPhi = nextPhi;
	}

	SnModel *sn = new SnModel(torus);

	add_model(sn, GsVec(0, 0, 0));
}

// Below is an example of how to control the main loop of an animation:
void MyViewer::run_animation ()
{
	if ( _animating ) return; // avoid recursive calls
	_animating = true;
	
	int ind = gs_random ( 0, rootg()->size()-1 ); // pick one child
	SnManipulator* manip = rootg()->get<SnManipulator>(ind); // access one of the manipulators
	GsMat m = manip->mat();

	double frdt = 1.0/30.0; // delta time to reach given number of frames per second
	double v = 4; // target velocity is 1 unit per second
	double t=0, lt=0, t0=gs_time();
	do // run for a while:
	{	while ( t-lt<frdt ) { ws_check(); t=gs_time()-t0; } // wait until it is time for next frame
		double yinc = (t-lt)*v;
		if ( t>2 ) yinc=-yinc; // after 2 secs: go down
		lt = t;
		m.e24 += (float)yinc;
		if ( m.e24<0 ) m.e24=0; // make sure it does not go below 0
		manip->initial_mat ( m );
		render(); // notify it needs redraw
		ws_check(); // redraw now
	}	while ( m.e24>0 );
	_animating = false;
}

void MyViewer::show_normals ( bool b )
{
	// Note that primitives are only converted to meshes in GsModel
	// at the first draw call.
	GsArray<GsVec> fn;
	SnGroup* r = (SnGroup*)root();
	for ( int k=0; k<r->size(); k++ )
	{	SnManipulator* manip = r->get<SnManipulator>(k);
		SnShape* s = manip->child<SnGroup>()->get<SnShape>(0);
		SnLines* l = manip->child<SnGroup>()->get<SnLines>(1);
		if ( !b ) { l->visible(false); continue; }
		l->visible ( true );
		if ( !l->empty() ) continue; // build only once
		l->init();
		if ( s->instance_name()==SnPrimitive::class_name )
		{	GsModel& m = *((SnModel*)s)->model();
			m.get_normals_per_face ( fn );
			const GsVec* n = fn.pt();
			float f = 0.33f;
			for ( int i=0; i<m.F.size(); i++ )
			{	const GsVec& a=m.V[m.F[i].a]; l->push ( a, a+(*n++)*f );
				const GsVec& b=m.V[m.F[i].b]; l->push ( b, b+(*n++)*f );
				const GsVec& c=m.V[m.F[i].c]; l->push ( c, c+(*n++)*f );
			}
		}  
	}
}

int MyViewer::handle_keyboard ( const GsEvent &e )
{
	int ret = WsViewer::handle_keyboard ( e ); // 1st let system check events
	if ( ret ) return ret;

	switch ( e.key )
	{	case GsEvent::KeyEsc : gs_exit(); return 1;
		case 'n' : { bool b=!_nbut->value(); _nbut->value(b); show_normals(b); return 1; }
		default: gsout<<"Key pressed: "<<e.key<<gsnl;
	}

	return 0;
}

int MyViewer::uievent ( int e )
{
	switch ( e )
	{	case EvNormals: show_normals(_nbut->value()); return 1;
		case EvAnimate: run_animation(); return 1;
		case EvExit: gs_exit();
	}
	return WsViewer::uievent(e);
}
